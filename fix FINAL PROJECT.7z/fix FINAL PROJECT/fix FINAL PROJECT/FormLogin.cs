﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class FormLogin : Form
    {
        private FormMenu formMenu;
        public FormLogin()
        {
            InitializeComponent();
        }

        private void buttonOpenMenu_Click(object sender, EventArgs e)
        {
            
            
            string usuario = txtUsuario.Text;
            string contraseña = txtContraseña.Text;

            if (usuario == "Russ" && contraseña == "123")
            {
                MessageBox.Show("Inicio de sesión exitoso. ¡Bienvenido, Russ!", "Inicio de sesión", MessageBoxButtons.OK, MessageBoxIcon.Information);
                formMenu = new FormMenu();
                formMenu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Credenciales inválidas. Inicio de sesión fallido.", "Inicio de sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

       

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
