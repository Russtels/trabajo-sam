﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace fix_FINAL_PROJECT
{
    internal class Class1
    {
        public double Add(double x, double y)
        {
            return x + y;
        }

        public void GetAndAddNumbers()
        {
            Console.WriteLine("Ingresa el primer número:");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingresa el segundo número:");
            double y = double.Parse(Console.ReadLine());

            double sum = Add(x, y);
            Console.WriteLine("La suma de los 2 números es {0}.", sum);
            Console.ReadKey();
        }
        public void CalculateAge(double x, double y, double z)
        {
            int currentYear = DateTime.Now.Year;

            int yearOfBirth = 1;
            int age = currentYear - yearOfBirth;
            
        }
        public void SimpleCalculator()
        {
            Console.WriteLine("ingresa el primer numero:");
            double firstNumber = double.Parse(Console.ReadLine());
            Console.WriteLine("ingresa el segundo numero:");
            double secondNumber = double.Parse(Console.ReadLine());
            double sum = firstNumber + secondNumber;
            double difference = firstNumber - secondNumber;
            double product = firstNumber * secondNumber;
            double quotient = firstNumber / secondNumber;
            Console.WriteLine("la suma es {0}", sum);
            Console.WriteLine("la resta es {0}", difference);
            Console.WriteLine("la multiplicacion es {0}", product);
            Console.WriteLine("la division es {0}", quotient);
        }
        public void CalculateRectangleArea()
        {
            Console.WriteLine("escribe el ancho del rectangulo(en cm)");
            double width = double.Parse(Console.ReadLine());
            Console.WriteLine("escribe la altura del rectangulo(en cm)");
            double height = double.Parse(Console.ReadLine());
            double area = width * height;
            Console.WriteLine("el area es " + area + " cm");
        }
        public void ListOfYearAgeAndName()
        {
            StreamWriter writer = new StreamWriter("data.txt");
            Console.WriteLine("ingresa tu nombre:");
            string name = Console.ReadLine();
            Console.WriteLine("ingresa tu fecha de nacimiento:");
            int yearOfBirth = int.Parse(Console.ReadLine());
            int age = DateTime.Now.Year - yearOfBirth;
            writer.WriteLine(name);
            writer.WriteLine(yearOfBirth);
            writer.WriteLine(age);
            writer.Close();
            Console.WriteLine("los datos :");
            Console.WriteLine(name);
            Console.WriteLine(yearOfBirth);
            Console.WriteLine(age);
            Console.WriteLine("han sido guardados correctamente.");
        }
        public void MaxAndMinNumbers()
        {
            Console.WriteLine("ingrese el primer numero ");
            int TestNum1 = int.Parse(Console.ReadLine());
            Console.WriteLine("ingrese el segundo numero ");
            int TestNum2 = int.Parse(Console.ReadLine());
            if (TestNum1 > TestNum2)
            {
                Console.WriteLine("el numero" + TestNum1 + "es mayor que el " + TestNum2);
            }
            else { Console.WriteLine("el numero " + TestNum1 + "es menor que el " + TestNum2); }
        }
        public void WhileForDo()
        {
            Console.WriteLine("while se ejecutara solo si la condicion es la asignada sin importar que ");
            Console.WriteLine("do while se ejecutara una vez y luego solo se ejecutara si la condicion es asignada o se vuelve a llamar desde otro metodo");
            Console.WriteLine("for se ejecutara un numero especifico de veces segun los parametros que se le proporcionen");
        }
        public void TenToOneHundred()
        {
            for (int i1 = 10; i1 <= 100; i1++)
            {
                Console.WriteLine(i1);
            }
        }
        public void ForToNumber()
        {
            Console.WriteLine("cuantas veces quieres repetir el bucle?");
            int timesRepite = int.Parse(Console.ReadLine());
            for (int i2 = 0; i2 <= timesRepite; i2++)
            {
                Console.WriteLine(i2);
            }

        }
        public void TwoToOneHundred()
        {
            for (int i3 = 2; i3 <= 100; i3 += 2)
            {
                Console.WriteLine(i3);
            }
        }
        public void MultiplyTable()
        {
            Console.WriteLine("digite el numero a obtener la tabla");
            int MultiNumber = int.Parse(Console.ReadLine());
            for (int i5 = 0; i5 <= 10; i5++)
            {
                int MultiResult = i5 * MultiNumber;
                Console.WriteLine(i5 + " x " + MultiNumber + " = " + MultiResult);
            }
            Console.ReadKey();
        }
        public void AllMultiplyTables()

        {
            Console.WriteLine("digite el numero a obtener la tabla del 1 al 20");
            int MultiNumber = int.Parse(Console.ReadLine());
            for (int i6 = 0; i6 <= 20; i6++)
            {
                int MultiResult = i6 * MultiNumber;
                Console.WriteLine(i6 + " x " + MultiNumber + " = " + MultiResult);
            }
            Console.ReadKey();
        }
        public void LeapYear()
        {
            List<int> years = new List<int>();
            for (int year = 1900; year <= 2021; year++)
            {
                years.Add(year);
            }

            foreach (int year in years)
            {

                if (year % 4 == 0)
                {
                    if (year % 100 == 0)
                    {
                        if (year % 400 == 0)
                        {
                            Console.WriteLine("{0} es año bisiesto.", year);
                        }
                        else
                        {
                            Console.WriteLine("{0} no es año bisiesto.", year);
                        }
                    }
                    else
                    {
                        Console.WriteLine("{0} es año bisiesto.", year);
                    }
                }
                else
                {
                    Console.WriteLine("{0} no es año bisiesto.", year);
                }
            }
        }
    }
}

