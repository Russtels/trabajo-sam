﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class edadForm : Form
    {
        public edadForm()
        {
            InitializeComponent();
        }

        private void edadForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int fecha = int.Parse(textBox1.Text);
            DateTime fechaActual = DateTime.Today;
            int edad = fechaActual.Year - fecha;    
            textBox2.Text = edad.ToString();

        }
    }
}
