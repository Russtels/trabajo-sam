﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace fix_FINAL_PROJECT
{
    public partial class minMax : Form
    {
        public minMax()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum1.Text);
            int num2 = int.Parse(txtNum2.Text);
            
            if (num1 > num2) 
            {
                txtNum3.Text = num1.ToString();
            }
            if (num1 < num2)
            {
                txtNum3.Text = num2.ToString();
            }
            if (num1 == num2)
            {
                txtNum3.Text = "son los mismos numeros";
            }



        }

        private void txtNum3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
