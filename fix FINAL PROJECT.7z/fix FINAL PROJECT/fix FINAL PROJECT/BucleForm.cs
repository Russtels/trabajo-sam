﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class BucleForm : Form
    {
        public BucleForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int v = int.Parse(txt1.Text);   
            for (int i = 0; i <= v; i++)
            {
                txt2.Text = "+" + i;
                
            }
        }
    }
}
