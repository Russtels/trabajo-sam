﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class dbForm : Form
    {

        private List<Persona> personas = new List<Persona>();
        public dbForm()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string telefono = txtTelefono.Text;
            string documento = txtDocumento.Text;

            Persona persona = new Persona(nombre, telefono, documento);
            personas.Add(persona);

            LimpiarCampos();
            ActualizarListaPersonas();
        }
        private void LimpiarCampos()
        {
            txtNombre.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtDocumento.Text = string.Empty;
        }
        private void ActualizarListaPersonas()
        {
            lstPersonas.Items.Clear();

            foreach (Persona persona in personas)
            {
                lstPersonas.Items.Add(persona.Nombre);
            }
        }

        private void lstPersonas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    public class Persona
    {
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Documento { get; set; }

        public Persona(string nombre, string telefono, string documento)
        {
            Nombre = nombre;
            Telefono = telefono;
            Documento = documento;
        }
    }
}

