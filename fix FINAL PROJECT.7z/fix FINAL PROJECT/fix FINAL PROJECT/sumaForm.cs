﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class sumaForm : Form
    {
        
        public sumaForm()
        {
            InitializeComponent();
        }



        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNum1.Text, out int num1) && int.TryParse(txtNum2.Text, out int num2))
            {
                
                int resultado = num1 + num2;
                txtResultado.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos en ambos campos.", "Error de entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void sumaForm_Load(object sender, EventArgs e)
        {

        }
    }
    
}
