﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class dosToCienForm : Form
    {
        private int contador;
        public dosToCienForm()
        {
            InitializeComponent();
            contador = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false; // Desactivar el botón mientras se realiza el conteo

            // Crear un hilo secundario para ejecutar el conteo
            Thread contadorThread = new Thread(RealizarConteo);
            contadorThread.Start();
        }
        private void RealizarConteo()
        {
            while (contador <= 100)
            {
                // Actualizar el contador en el formulario (hilo principal)
                Invoke((MethodInvoker)delegate
                {
                    label2.Text = contador.ToString();
                });

                contador += 2;

                // Retraso de 1 segundo
                Thread.Sleep(250);
            }

            // Habilitar nuevamente el botón al finalizar el conteo
            Invoke((MethodInvoker)delegate
            {
                label2.Enabled = true;
            });
        }
    }
}
