﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class unoToCienForm : Form
    {
        private int contador;
        public unoToCienForm()
        {
            InitializeComponent();
            contador = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;

            Thread contadorThread = new Thread(RealizarConteo);
            contadorThread.Start();
        }
        private void RealizarConteo()
        {
            while (contador <= 100)
            {
                Invoke((MethodInvoker)delegate
                {
                    label2.Text = contador.ToString();
                });

                contador += 1;

                Thread.Sleep(250);
            }

            Invoke((MethodInvoker)delegate
            {
                label2.Enabled = true;
            });
        }
    }
}
