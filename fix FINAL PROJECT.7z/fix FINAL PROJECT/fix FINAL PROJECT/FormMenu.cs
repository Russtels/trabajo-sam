﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class FormMenu : Form
    {
        private Form formularioActual = null;
        public FormMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (panelSideMenu.Visible == false)
            {
                panelSideMenu.Visible = true;
            }
            else
            {
                panelSideMenu.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }

            Form suma = new sumaForm();
            suma.TopLevel = false;
            suma.FormBorderStyle = FormBorderStyle.None;
            suma.Dock = DockStyle.Fill;
            panelShow.Controls.Add(suma);
            suma.Show();

            formularioActual = suma;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }

            Form edad = new edadForm();
            edad.TopLevel = false;
            edad.FormBorderStyle = FormBorderStyle.None;
            edad.Dock = DockStyle.Fill;
            panelShow.Controls.Add(edad);
            edad.Show();

            formularioActual = edad;
        }

        private void panelSideMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }

            Form calculadora = new calculadoraForm();
            calculadora.TopLevel = false;
            calculadora.FormBorderStyle = FormBorderStyle.None;
            calculadora.Dock = DockStyle.Fill;
            panelShow.Controls.Add(calculadora);
            calculadora.Show();

            formularioActual = calculadora;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }

            Form area = new areaForm();
            area.TopLevel = false;
            area.FormBorderStyle = FormBorderStyle.None;
            area.Dock = DockStyle.Fill;
            panelShow.Controls.Add(area);
            area.Show();

            formularioActual = area;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }

            Form DB = new dbForm();
            DB.TopLevel = false;
            DB.FormBorderStyle = FormBorderStyle.None;
            DB.Dock = DockStyle.Fill;
            panelShow.Controls.Add(DB);
            DB.Show();

            formularioActual = DB;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }
            Form numaxmin = new minMax();
            numaxmin.TopLevel = false;
            numaxmin.FormBorderStyle = FormBorderStyle.None;
            numaxmin.Dock = DockStyle.Fill;
            panelShow.Controls.Add(numaxmin);
            numaxmin.Show();

            formularioActual = numaxmin;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }

            Form bucle = new BucleForm();
            bucle.TopLevel = false;
            bucle.FormBorderStyle = FormBorderStyle.None;
            bucle.Dock = DockStyle.Fill;
            panelShow.Controls.Add(bucle);
            bucle.Show();

            formularioActual = bucle;


        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }
            Form twoTo100 = new dosToCienForm();
            twoTo100.TopLevel = false;
            twoTo100.FormBorderStyle = FormBorderStyle.None;
            twoTo100.Dock = DockStyle.Fill;
            panelShow.Controls.Add(twoTo100);
            twoTo100.Show();

            formularioActual = twoTo100;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }
            Form tabla10 = new tablaDiezForm();
            tabla10.TopLevel = false;
            tabla10.FormBorderStyle = FormBorderStyle.None;
            tabla10.Dock = DockStyle.Fill;
            panelShow.Controls.Add(tabla10);
            tabla10.Show();

            formularioActual = tabla10;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }
            Form tabla20 = new tablaVeinteForm();
            tabla20.TopLevel = false;
            tabla20.FormBorderStyle = FormBorderStyle.None;
            tabla20.Dock = DockStyle.Fill;
            panelShow.Controls.Add(tabla20);
            tabla20.Show();

            formularioActual = tabla20;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }
            Form leapYear = new leapYearForm();
            leapYear.TopLevel = false;
            leapYear.FormBorderStyle = FormBorderStyle.None;
            leapYear.Dock = DockStyle.Fill;
            panelShow.Controls.Add(leapYear);
            leapYear.Show();

            formularioActual = leapYear;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }
            Form oneTo100 = new unoToCienForm();
            oneTo100.TopLevel = false;
            oneTo100.FormBorderStyle = FormBorderStyle.None;
            oneTo100.Dock = DockStyle.Fill;
            panelShow.Controls.Add(oneTo100);
            oneTo100.Show();

            formularioActual = oneTo100;
        }
        
        private void button8_Click(object sender, EventArgs e)
        {
            if (formularioActual != null)
            {
                formularioActual.Hide();
            }
            Form wdf = new whileDoForForm();
            wdf.TopLevel = false;
            wdf.FormBorderStyle = FormBorderStyle.None;
            wdf.Dock = DockStyle.Fill;
            panelShow.Controls.Add(wdf);
            wdf.Show();

            formularioActual = wdf;
        }

        private void panelShow_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
