﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace fix_FINAL_PROJECT
{
    public partial class calculadoraForm : Form
    {
        public calculadoraForm()
        {
            InitializeComponent();
        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double numero1) && double.TryParse(textBox2.Text, out double numero2))
            {
                double resultado = numero1 + numero2;
                textBox3.Text = resultado.ToString();
            }
            else
            {
                textBox3.Text = "Error de entrada";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double numero1) && double.TryParse(textBox2.Text, out double numero2))
            {
                double resultado = numero1 - numero2;
                textBox3.Text = resultado.ToString();
            }
            else
            {
                textBox3.Text = "Error de entrada";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double numero1) && double.TryParse(textBox2.Text, out double numero2))
            {
                double resultado = numero1 * numero2;
                textBox3.Text = resultado.ToString();
            }
            else
            {
                textBox3.Text = "Error de entrada";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double numero1) && double.TryParse(textBox2.Text, out double numero2))
            {
                if (numero2 != 0)
                {
                    double resultado = numero1 / numero2;
                    textBox3.Text = resultado.ToString();
                }
                else
                {
                    textBox3.Text = "Error: División por cero";
                }
            }
            else
            {
                textBox3.Text = "Error de entrada";
            }
        }
    }
}
    

