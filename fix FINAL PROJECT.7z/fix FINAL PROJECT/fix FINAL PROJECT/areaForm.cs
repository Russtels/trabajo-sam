﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class areaForm : Form
    {
        public areaForm()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double largo) && double.TryParse(textBox2.Text, out double ancho))
            {
                double area = largo * ancho;
                textBox3.Text = area.ToString();
            }
            else
            {
                textBox3.Text = "Error de entrada";
            }
        }
    }
}
