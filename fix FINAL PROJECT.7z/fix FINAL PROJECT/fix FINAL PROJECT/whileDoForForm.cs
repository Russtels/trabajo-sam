﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fix_FINAL_PROJECT
{
    public partial class whileDoForForm : Form
    {
        public whileDoForForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                textBox1.Text = "El bucle while ejecuta un bloque de código mientras una condición especificada sea verdadera. Antes de cada iteración, se verifica la condición. Si la condición es verdadera, el bloque de código se ejecuta; de lo contrario, el bucle se detiene."; ;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "El bucle do-while es similar al bucle while, pero la condición se verifica después de cada iteración. Esto significa que el bloque de código se ejecuta al menos una vez antes de verificar la condición.";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "El bucle for se utiliza cuando se conoce de antemano el número exacto de iteraciones que se deben realizar. Se compone de tres partes: la inicialización, la condición y la expresión de incremento.";
        }
    }
}
